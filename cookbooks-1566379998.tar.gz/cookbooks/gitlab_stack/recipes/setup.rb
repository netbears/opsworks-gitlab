# frozen_string_literal: true

execute 'apt-get update'

(node['base_packages'] + node['custom_packages']).each do |pkg|
  package pkg
end

include_recipe 'gitlab_stack::swap'

include_recipe 'gitlab_stack::gitlab_cleoo'

include_recipe 'ntp::default'
